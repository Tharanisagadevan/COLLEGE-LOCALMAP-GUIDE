const recognition = new window.webkitSpeechRecognition();
recognition.continuous = true;

const messagesList = document.getElementById('messages');
const startBtn = document.getElementById('start-btn');

const responses = {
    "hi": "Hello! I'm Robo, your college AI guide. How can I assist you today?",
    "assist me": "Sure thing! Where are you trying to go?",
    "guiding you from one place to another": "Absolutely! Just let me know your starting point and destination, and I'll provide you with directions.",
    "admissions": "Looking to join us? Our admissions process usually starts in the fall. Do you need information on application requirements?",
    "campus tour": "Exploring the campus? We offer tours every Tuesday and Thursday. Would you like to schedule one?",
    "scholarship": "Planning your finances? We have various scholarships available for eligible students. Do you want to know more about them?",
    "student life": "Interested in student life? Our campus is bustling with activities and clubs. What are you curious about?",
    "academic calendar": "Keeping track of important dates? You can find our academic calendar on our website. Need help finding it?",
    "career services": "Thinking about your future career? Our career services department can help with resume building, internships, and job fairs. What aspect are you interested in?",
    "bye": "Alright! If you have any more questions in the future, feel free to ask. Goodbye for now!",
    "default": "I'm sorry, I didn't quite catch that. Could you please rephrase or ask in a different way?"
  };
recognition.onstart = function() {
  console.log('Speech recognition started...');
};

recognition.onerror = function(event) {
  console.error('Speech recognition error:', event.error);
};

recognition.onresult = function(event) {
  const last = event.results.length - 1;
  const message = event.results[last][0].transcript;
  addMessage('user', message);
  processMessage(message);
};

function addMessage(sender, message) {
  const li = document.createElement('li');
  li.className = sender + '-message';
  li.textContent = message;
  messagesList.appendChild(li);
}

function processMessage(message) {
  let reply;
  message = message.toLowerCase(); // Convert message to lowercase for case insensitivity
  for (const key in responses) {
    if (message.includes(key)) {
      reply = responses[key];
      break;
    }
  }
  reply = reply || responses["default"]; // Use default response if no match found
  addMessage('bot', reply);
  speak(reply);
  
  // Delay for 1 second after speaking before allowing the next question
  setTimeout(function() {
    recognition.start();
  }, 3000);
}

function speak(text) {
  const synth = window.speechSynthesis;
  const utterance = new SpeechSynthesisUtterance(text);
  synth.speak(utterance);
}

startBtn.addEventListener('click', function() {
  recognition.start();
});